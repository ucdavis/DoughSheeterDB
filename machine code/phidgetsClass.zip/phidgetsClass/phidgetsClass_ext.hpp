#ifndef STEPPER_HPP
#define STEPPER_HPP

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <fstream>
#include <unistd.h>
#include <phidget22.h>
#include <chrono>
#include <time.h>

#include "GIL.hpp"

using namespace std::chrono;

// PhidgetsClass
class phidgetsClass{

  public:
  
  // Constructor
  phidgetsClass();
  ~phidgetsClass();


  // Destructor
  //~phidgetsClass();

  // Timestamp variable
  milliseconds ms;

  // Move the stepper
  void initStepper();
  void moveStepper(float position);
  void stopStepper();

  // Run and stop and the motors
  void runMotors(int direction, float speed);
  void stopMotors();

  //  Run and stop and the motors using the encoders to close the loop
  void runMotorsLoop(int direction, float speed);
  void stopMotorsLoop();
  static void CCONV onPositionChangeHandler_M0(PhidgetEncoderHandle ch, void *ctx, int positionChange, double timeChange, int indexTriggered);// Callbacks for the encoders
  static void CCONV onPositionChangeHandler_M1(PhidgetEncoderHandle ch, void *ctx, int positionChange, double timeChange, int indexTriggered);

  // Run and stop and the conveyors
  void runConveyors(int direction_0, int speed_0, int direction_1, int speed_1);
  void runConveyor_0(int direction, int speed);
  void runConveyor_1(int direction, int speed);
  void stopConveyors();
  void stopConveyor_0();
  void stopConveyor_1();

  // Grabe and save the load cells values
  void loadCells();
  void stopLoadCells();

  // Variables for the control of the rollers
  int samplingTime = 20; // (ms)
  int samplingFreq = int(1/(samplingTime*0.001)); 
  float gearRatio = 10.0/18.0;
  int nbTicksPerTurn = 43*76;
  float rollerPerimeter = 235.39;
  float encoderToRoller = samplingFreq*gearRatio*rollerPerimeter/nbTicksPerTurn;
  float Kp = 0.5;
  
  static int* p_ticksPerSample_M0;
  static int* p_ticksPerSample_M1; 

  static bool* p_saveDataRoller;
  bool saveDataRoller = true;  

  //Setup the name of the file to save
  void set_lcFileName(std::string name);
  void set_lc0FileName(std::string name);
  void set_lc1FileName(std::string name);
  

  private:

  // Time out delay (ms)
  const int timeout = 500;

  // Return code for Phidgets functions
  PhidgetReturnCode res;
  const char *errs;

  // Channel for the stepper motor controller
  PhidgetStepperHandle ch_stepper;

  // Channel for the DC motors controllers
  PhidgetDCMotorHandle ch_M0; // Motor #0
  PhidgetDCMotorHandle ch_M1; // Motor #1

  // Channels for the motor encoders
  PhidgetEncoderHandle ch_encoder_M0; // Motor #0
  PhidgetEncoderHandle ch_encoder_M1; // Motor #1

  // Channels for the analogic outputs 
  PhidgetVoltageOutputHandle ch_speed_C0; // Speed for conveyor #0
  PhidgetVoltageOutputHandle ch_speed_C1; // Speed for conveyor #1

  // Channels for the digital outputs 
  PhidgetDigitalOutputHandle ch_SS_C0; // Start/Stop for conveyor #0
  PhidgetDigitalOutputHandle ch_FB_C0; // Forward/Backward for conveyor #0
  PhidgetDigitalOutputHandle ch_SS_C1; // Start/Stop for conveyor #1
  PhidgetDigitalOutputHandle ch_FB_C1; // Forward/Backward for conveyor #1

  // Channel for the digital output 
  PhidgetDigitalInputHandle ch_bladeInit; // Detect the initial blade position

  // Channels for the load cells
  PhidgetVoltageRatioInputHandle ch_LC0; // Load cell #0
  PhidgetVoltageRatioInputHandle ch_LC1; // Load cell #1

  // Initial stepper position
  double* intGap;

  // mm to RPm ratio for the conveyors
  float mmtoRPM = 1.783;

  // Display error function
  void displayError();

  // Flag to control the roller
  bool controlRoller;

  // Flag to control the load cells saving
  bool saveLoadCells;

  // File to save
  std::string lcFileName, lc0FileName, lc1FileName;

  // Ratio to convert from volt to newton
  float voltToNewton = 50/0.004*4.44822;

};
#endif
