#include <boost/python.hpp>

#include "phidgetsClass_ext.hpp"

/* ------------------------------------- */
/* ---------- Static elements ---------- */
/* ------------------------------------- */

int* phidgetsClass::p_ticksPerSample_M0 = new int;
int* phidgetsClass::p_ticksPerSample_M1 = new int;

bool* phidgetsClass::p_saveDataRoller = new bool;

/* --------------------------------------------------- */
/* ---------- declaration of extra function ---------- */
/* --------------------------------------------------- */

float convertConveyorSpeed(int speed);

/* --------------------------------- */
/* ---------- Constructor ---------- */
/* --------------------------------- */
phidgetsClass::~phidgetsClass()
{
   std::cout << "Phidgets desconstructor" << std::endl;
}

phidgetsClass::phidgetsClass()
{
   std::cout << "Phidgets constructor" << std::endl;

   //Enable logging to stdout
   //PhidgetLog_enable(PHIDGET_LOG_INFO, NULL);

   // Setup the channel for the stepper
   PhidgetStepper_create(&ch_stepper);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_stepper, 399181);   
   Phidget_setChannel((PhidgetHandle)ch_stepper, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_stepper, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Stepper ok" << std::endl;}

   // Setup the channel for motor controler #0 (Bottom motor)
   PhidgetDCMotor_create(&ch_M0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_M0, 465596);   
   Phidget_setChannel((PhidgetHandle)ch_M0, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_M0, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Motor 0 ok" << std::endl;}

   /*PhidgetDCMotor_create(&ch_M0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_M0, 487947);   
   Phidget_setChannel((PhidgetHandle)ch_M0, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_M0, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Motor 0 ok" << std::endl;}*/

   // Setup the channel for motor controler #1 (Top motor)
   PhidgetDCMotor_create(&ch_M1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_M1, 482474);   
   Phidget_setChannel((PhidgetHandle)ch_M1, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_M1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Motor 1 ok" << std::endl;}

   /*PhidgetDCMotor_create(&ch_M1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)chttps://www.lequipe.fr/h_M1, 487947);   
   Phidget_setChannel((PhidgetHandle)ch_M1, 1);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_M1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Motor 1 ok" << std::endl;}*/

   // Setup the channel for motor encoder #0 (Bottom encoder)
   PhidgetEncoder_create(&ch_encoder_M0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_encoder_M0, 495375);  
   Phidget_setHubPort((PhidgetHandle)ch_encoder_M0, 0);                 
   Phidget_setChannel((PhidgetHandle)ch_encoder_M0, 0); 
   PhidgetEncoder_setOnPositionChangeHandler(ch_encoder_M0, onPositionChangeHandler_M0, NULL);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_encoder_M0, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Encoder 0 ok" << std::endl;}
   PhidgetEncoder_setIOMode(ch_encoder_M0,ENCODER_IO_MODE_OPEN_COLLECTOR_10K);
   PhidgetEncoder_setDataInterval(ch_encoder_M0,20); 	

   // Setup the channel for motor encoder #1 (Top encoder)
   PhidgetEncoder_create(&ch_encoder_M1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_encoder_M1, 495375);  
   Phidget_setHubPort((PhidgetHandle)ch_encoder_M1, 1);                 
   Phidget_setChannel((PhidgetHandle)ch_encoder_M1, 0); 
   PhidgetEncoder_setOnPositionChangeHandler(ch_encoder_M1, onPositionChangeHandler_M1, NULL);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_encoder_M1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Encoder 1 ok" << std::endl;}
   PhidgetEncoder_setIOMode(ch_encoder_M1,ENCODER_IO_MODE_OPEN_COLLECTOR_10K);
   PhidgetEncoder_setDataInterval(ch_encoder_M1,20); 

   // Setup the channel for analogic output #0
   PhidgetVoltageOutput_create(&ch_speed_C0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_speed_C0, 493907);   
   Phidget_setChannel((PhidgetHandle)ch_speed_C0, 1);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_speed_C0, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Analogic 0 ok" << std::endl;}
   // Setup the channel for analogic output #1
   PhidgetVoltageOutput_create(&ch_speed_C1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_speed_C1, 493907);   
   Phidget_setChannel((PhidgetHandle)ch_speed_C1, 2);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_speed_C1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Analogic 1 ok" << std::endl;}
   // Setup the channel for digital output #0
   PhidgetDigitalOutput_create(&ch_SS_C0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_SS_C0, 495375); 
   Phidget_setHubPort((PhidgetHandle)ch_SS_C0, 4);   
   Phidget_setChannel((PhidgetHandle)ch_SS_C0, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_SS_C0, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Digital 0 ok" << std::endl;}
   // Setup the channel for digital output #1
   PhidgetDigitalOutput_create(&ch_FB_C0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_FB_C0, 495375);
   Phidget_setHubPort((PhidgetHandle)ch_FB_C0, 4);    
   Phidget_setChannel((PhidgetHandle)ch_FB_C0, 1);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_FB_C0, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Digital 1 ok" << std::endl;}
   // Setup the channel for digital output #2
   PhidgetDigitalOutput_create(&ch_SS_C1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_SS_C1, 495375); 
   Phidget_setHubPort((PhidgetHandle)ch_SS_C1, 4);   
   Phidget_setChannel((PhidgetHandle)ch_SS_C1, 2);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_SS_C1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Digital 2 ok" << std::endl;}
   // Setup the channel for digital output #3
   PhidgetDigitalOutput_create(&ch_FB_C1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_FB_C1, 495375); 
   Phidget_setHubPort((PhidgetHandle)ch_FB_C1, 4);   
   Phidget_setChannel((PhidgetHandle)ch_FB_C1, 3);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_FB_C1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Digital 3 ok" << std::endl;}  

   // Setup the channel for the intial blade position
   PhidgetDigitalInput_create(&ch_bladeInit);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_bladeInit, 495375); 
   Phidget_setHubPort((PhidgetHandle)ch_bladeInit, 3);   
   Phidget_setChannel((PhidgetHandle)ch_bladeInit, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_bladeInit, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Digital output ok" << std::endl;} 


   // Setup the channel for the load cell #0
   PhidgetVoltageRatioInput_create(&ch_LC0);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_LC0, 495375); 
   Phidget_setHubPort((PhidgetHandle)ch_LC0, 2);   
   Phidget_setChannel((PhidgetHandle)ch_LC0, 0);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_LC0, timeout);
   displayError();  
if (res == EPHIDGET_OK){std::cout << "Load cell 0 ok" << std::endl;} 
   PhidgetVoltageRatioInput_setDataInterval(ch_LC0, 20);

   // Setup the channel for the load cell #1
   PhidgetVoltageRatioInput_create(&ch_LC1);
   Phidget_setDeviceSerialNumber((PhidgetHandle)ch_LC1, 495375); 
   Phidget_setHubPort((PhidgetHandle)ch_LC1, 2);   
   Phidget_setChannel((PhidgetHandle)ch_LC1, 1);
   res = Phidget_openWaitForAttachment((PhidgetHandle)ch_LC1, timeout);
   displayError();
if (res == EPHIDGET_OK){std::cout << "Load cell 1 ok" << std::endl;} 
   PhidgetVoltageRatioInput_setDataInterval(ch_LC1, 20);

// Setup the flags
*p_saveDataRoller = false;

}

/*
phidgetsClass::~phidgetsClass()
{
   std::cout << "Phidgets desconstructor" << std::endl;
}
*/

/* ----------------------------- */
/* ---------- Stepper ---------- */
/* ----------------------------- */

void phidgetsClass::initStepper()
{

std::cout << "Init stepper" << std::endl;

   // 1 - Move the stepper to its initial position
   
   // Set up the speed control mode
   PhidgetStepper_setControlMode(ch_stepper, CONTROL_MODE_RUN);
   // Engage the stepper
   PhidgetStepper_setEngaged(ch_stepper, 1);
   // Setup velocity limit
   PhidgetStepper_setVelocityLimit(ch_stepper,-10000);
   // Wait for the stepper to be at its initial position
   bool atInit = false;
   int* state = new int;
   while(!atInit)
   {

      // Get position sensor state
      PhidgetDigitalInput_getState(ch_bladeInit, state);

      // Stop the loop at the intial position 
      if(*state == 0){atInit = true;}

   }
   // Disengage the stepper
   PhidgetStepper_setEngaged(ch_stepper, 0);

   // 2 - Setup for the rest of the experiment
   
   // Set up the step control mode
   PhidgetStepper_setControlMode(ch_stepper, CONTROL_MODE_STEP);
   // Setup the acceleration
   PhidgetStepper_setAcceleration(ch_stepper, 10000);
   // Setup current limit
   PhidgetStepper_setCurrentLimit(ch_stepper,1);
   // Setup velocity limit
   PhidgetStepper_setVelocityLimit(ch_stepper,15000);

   // 3 - Zeroing the position
   intGap = new double;   
   
   // Read the current position
   PhidgetStepper_getPosition(ch_stepper, intGap);

}


void phidgetsClass::moveStepper(float position)
{
 
   // Take into account the roller gap
   position = position - 1.78;

   // Compute the target in steps
   int steps = int(position*19362)+(*intGap);

   // Engage the stepper
   PhidgetStepper_setEngaged(ch_stepper, 1);
   
   // Setup the desired position
   PhidgetStepper_setTargetPosition(ch_stepper, steps);
   
   // Wait while the stepper is moving
   int* moving;
   *moving = 1;
   while(*moving){PhidgetStepper_getIsMoving(ch_stepper, moving);}
   
   // Disengage the stepper
   PhidgetStepper_setEngaged(ch_stepper, 0);

}

void phidgetsClass::stopStepper()
{
  // Disengage the stepper
  PhidgetStepper_setEngaged(ch_stepper, 0);
}

/* ------------------------------- */
/* ---------- DC motors ---------- */
/* ------------------------------- */

void phidgetsClass::runMotors(int direction, float speed)
{

   // Check the value of the speed
   if(speed > 1){speed = 0.5;}

   if(direction == 1)
   {
      PhidgetDCMotor_setTargetVelocity(ch_M0, speed);
      PhidgetDCMotor_setTargetVelocity(ch_M1, speed);
   }
   else
   {
      PhidgetDCMotor_setTargetVelocity(ch_M0, -speed);
      PhidgetDCMotor_setTargetVelocity(ch_M1, -speed);
   }
}

void phidgetsClass::stopMotors()
{

   PhidgetDCMotor_setTargetVelocity(ch_M0, 0);
   PhidgetDCMotor_setTargetVelocity(ch_M1, 0);

}

/* ------------------------------------------------ */
/* ---------- DC motors with closed loop ---------- */
/* ------------------------------------------------ */

void phidgetsClass::runMotorsLoop(int direction, float speed)
{
   
   // Release GIl for Pyhton multi threading
   GILReleaser releaser;

   if((speed < 20.0) || (speed > 180.0)){std::cout << "Speed not taken into account" << std::endl;}

   std::cout << "Enable the encoders" << std::endl;
   // Enable the encoders
   PhidgetEncoder_setEnabled(ch_encoder_M0, 1);
   PhidgetEncoder_setEnabled(ch_encoder_M1, 1);
   
   // Desired speed
   int ticksSecRef = round(speed/encoderToRoller);
std::cout << "tickSecRef: " << ticksSecRef << std::endl;
   float refInputM0, refInputM1;
   float controlInput_M0, controlInput_M1;

   // Compute the input of reference
   refInputM0 = float(ticksSecRef - 10)/100.0 + 0.2;
   refInputM1 = float(ticksSecRef - 10)/100.0 + 0.12;

   /*
   if(ticksSecRef == 10){refInputM1 = 0.13; refInputM0 = 0.18;}
   else if(ticksSecRef == 15){refInputM1 = 0.18; refInputM0 = 0.22;}
   else if(ticksSecRef == 20){refInputM1 = 0.25; refInputM0 = 0.29;}
   else if(ticksSecRef == 25){refInputM1 = 0.3; refInputM0 = 0.34;}
   else if(ticksSecRef == 30){refInputM1 = 0.36; refInputM0 = 0.4;}
   else if(ticksSecRef == 35){refInputM1 = 0.41; refInputM0 = 0.45;}
   else if(ticksSecRef == 40){refInputM1 = 0.46; refInputM0 = 0.5;}
   else if(ticksSecRef == 45){refInputM1 = 0.52; refInputM0 = 0.56;}
   else if(ticksSecRef == 50){refInputM1 = 0.58; refInputM0 = 0.62;}
   else if(ticksSecRef == 55){refInputM1 = 0.63; refInputM0 = 0.68;}
   else if(ticksSecRef == 60){refInputM1 = 0.69; refInputM0 = 0.74;}
   else if(ticksSecRef == 65){refInputM1 = 0.74; refInputM0 = 0.77;}
   else if(ticksSecRef == 70){refInputM1 = 0.79; refInputM0 = 0.83;}
   else if(ticksSecRef == 75){refInputM1 = 0.85; refInputM0 = 0.89;}
   else if(ticksSecRef == 80){refInputM1 = 0.9; refInputM0 = 0.94;}
   else if(ticksSecRef == 85){refInputM1 = 0.95; refInputM0 = 0.99;}
   else{std::cout << "Speed not taken into account" << std::endl;}
   */

   // Start the control of the rollers
   controlRoller = true;

   // Start to save the data
   if(saveDataRoller){*p_saveDataRoller = true;}

   float intregalTermM0 = 0.0;
   float intregalTermM1 = 0.0;
   float errorM0, errorM1;
   while(controlRoller)
   {
      // Compute the control input
      //controlInput_M0 = direction;//*refInputM0;// + (float)(Kp*(-direction*ticksSecRef - *p_ticksPerSample_M0));
      //controlInput_M1 = direction;//*refInputM1;// + (float)(Kp*(direction*ticksSecRef - *p_ticksPerSample_M1));

      errorM0 = -(-direction*ticksSecRef - *p_ticksPerSample_M0);
      errorM1 = (direction*ticksSecRef - *p_ticksPerSample_M1);
      intregalTermM0 += errorM0*0.02;
      intregalTermM1 += errorM1*0.02;
      controlInput_M0 = (float)(0.1*errorM0 + 0.00005*intregalTermM0);
      controlInput_M1 = (float)(0.1*errorM1 + 0.0005*intregalTermM1);
//std::cout << "M0: " << controlInput_M0 << "M1: " << controlInput_M1 << std::endl;
      // To avoid command over |1|
      if (abs(controlInput_M0) >= 1.0){controlInput_M0 = direction;}
      if (abs(controlInput_M1) >= 1.0){controlInput_M1 = direction;}

      PhidgetDCMotor_setTargetVelocity(ch_M0, controlInput_M0);
      PhidgetDCMotor_setTargetVelocity(ch_M1, controlInput_M1);      
   }
}



void phidgetsClass::stopMotorsLoop()
{

   // Disable the encoders
   PhidgetEncoder_setEnabled(ch_encoder_M0, 0);
   PhidgetEncoder_setEnabled(ch_encoder_M1, 0);

   // Stop the closed loop control
   controlRoller = false;

   // Setup the rollers speed to 0
   for(int idx = 0; idx < 10; idx++)
   {
      PhidgetDCMotor_setTargetVelocity(ch_M0, 0.0);
      PhidgetDCMotor_setTargetVelocity(ch_M1, 0.0);
   }
}

void CCONV phidgetsClass::onPositionChangeHandler_M0(PhidgetEncoderHandle ch, void *ctx, int positionChange, double timeChange, int indexTriggered) 
{  
  // Copy and update the position change
  *p_ticksPerSample_M0 = positionChange;

  if(*p_saveDataRoller)
  {
     std::ofstream fileStreamR0;
     fileStreamR0.open("Roller0.txt", std::ios::out | std::ios::app);
     fileStreamR0 << *p_ticksPerSample_M0 << std::endl;
     fileStreamR0.close();
  }
}

void CCONV phidgetsClass::onPositionChangeHandler_M1(PhidgetEncoderHandle ch, void *ctx, int positionChange, double timeChange, int indexTriggered) 
{  
  // Copy and update the position change
  *p_ticksPerSample_M1 = positionChange;

  if(*p_saveDataRoller)
  {
     std::ofstream fileStreamR1;
     fileStreamR1.open("Roller1.txt", std::ios::out | std::ios::app);
     fileStreamR1 << *p_ticksPerSample_M1 << std::endl;
     fileStreamR1.close();
  }
}


/* ------------------------------ */
/* ---------- Conveyor ---------- */
/* ------------------------------ */

void phidgetsClass::runConveyors(int direction_0, int speed_0, int direction_1, int speed_1)
{

   //---------------------
   // Speed conveyor 0

   // Check if the desired speed is taken into account for conveyor 0
   if((speed_0 < 20) || (speed_0 >= 180)){std::cout << "Required speed for conveyor 0 is not taken into account" << std::endl;}

   // Compute the voltage to apply
   float coeff_a_0 = 0.02;
   float coeff_b_0 = 1.025;
   float volts_0 = (speed_0 - 20.0)*coeff_a_0 + coeff_b_0;

   //---------------------
   // Speed conveyor 1

   // Check if the desired speed is taken into account
   if((speed_1 < 20) || (speed_1 >= 180)){std::cout << "Required speed for conveyor 1 is not taken into account" << std::endl;}

   // Compute the voltage to apply
   float coeff_a_1 = 0.02;
   float coeff_b_1 = 1.0;
   float volts_1 = (speed_1 - 20.0)*coeff_a_1 + coeff_b_1;

   //---------------------
   // Activate the Phidgets
 
   // Setup the speed
   
   PhidgetVoltageOutput_setVoltage(ch_speed_C0, volts_0);
   PhidgetVoltageOutput_setEnabled(ch_speed_C0, 1);
   
   PhidgetVoltageOutput_setVoltage(ch_speed_C1, volts_1);
   PhidgetVoltageOutput_setEnabled(ch_speed_C1, 1);

   // Setup the direction
   PhidgetDigitalOutput_setState(ch_FB_C0, direction_0);
   PhidgetDigitalOutput_setState(ch_FB_C1, direction_1);

   // Wait for one sec
   sleep(2);

   // Start the conveyor
   PhidgetDigitalOutput_setState(ch_SS_C0, 1);
   PhidgetDigitalOutput_setState(ch_SS_C1, 1);
}

void phidgetsClass::runConveyor_0(int direction, int speed)
{

   // Check if the desired speed is taken into account
   if((speed < 20) || (speed >= 180)){std::cout << "Required speed not taken into account" << std::endl;}

   // Compute the voltage to apply
   float coeff_a = 0.02;
   float coeff_b = 1.025;
   float volts = (speed - 20.0)*coeff_a + coeff_b;

   // Setupt the speed
   PhidgetVoltageOutput_setVoltage(ch_speed_C0, volts);
   PhidgetVoltageOutput_setEnabled(ch_speed_C0, 1);

   // Setup the direction
   PhidgetDigitalOutput_setState(ch_FB_C0, direction);

   // Wait for one sec
   sleep(2);

   // Start the conveyor
   PhidgetDigitalOutput_setState(ch_SS_C0, 1);

}
  
void phidgetsClass::runConveyor_1(int direction, int speed)
{

   // Check if the desired speed is taken into account
   if((speed < 20) || (speed >= 180)){std::cout << "Required speed not taken into account" << std::endl;}

   // Compute the voltage to apply
   float coeff_a = 0.02;
   float coeff_b = 1.0;
   float volts = (speed - 20.0)*coeff_a + coeff_b;

   // Setupt the speed
   PhidgetVoltageOutput_setVoltage(ch_speed_C1, volts);
   PhidgetVoltageOutput_setEnabled(ch_speed_C1, 1);

   // Setup the direction
   PhidgetDigitalOutput_setState(ch_FB_C1, direction);

   // Wait for one sec
   sleep(2);

   // Start the conveyor
   PhidgetDigitalOutput_setState(ch_SS_C1, 1);

}
 
void phidgetsClass::stopConveyors()
{

   // Setup the speed
   PhidgetVoltageOutput_setVoltage(ch_speed_C0, 0.0);
   PhidgetVoltageOutput_setEnabled(ch_speed_C0, 0);
   PhidgetVoltageOutput_setVoltage(ch_speed_C1, 0.0);
   PhidgetVoltageOutput_setEnabled(ch_speed_C1, 0);

   // Stop the conveyor
   PhidgetDigitalOutput_setState(ch_SS_C0, 0);
   PhidgetDigitalOutput_setState(ch_SS_C1, 0);

}


void phidgetsClass::stopConveyor_0()
{

   // Setup the speed
   PhidgetVoltageOutput_setVoltage(ch_speed_C0, 0.0);
   PhidgetVoltageOutput_setEnabled(ch_speed_C0, 0);

   // Stop the conveyor
   PhidgetDigitalOutput_setState(ch_SS_C0, 0);

}
  
void phidgetsClass::stopConveyor_1()
{

   // Setup the speed
   PhidgetVoltageOutput_setVoltage(ch_speed_C1, 0.0);
   PhidgetVoltageOutput_setEnabled(ch_speed_C1, 0);

   // Stop the conveyor
   PhidgetDigitalOutput_setState(ch_SS_C1, 0);

}

/* -------------------------------- */
/* ---------- Load cells ---------- */
/* -------------------------------- */


void phidgetsClass::loadCells()
{

   // Release GIl for Pyhton multi threading
   GILReleaser releaser;

   // Variables to control the loop duration
   clock_t begin;
   double elapsed_secs;

   // Open the file to save the data
   std::ofstream fileStreamLC;
   fileStreamLC.open(lcFileName.c_str(), std::ios::out );

   double* voltageRatio_lco = (double*) new double;
   double* voltageRatio_lc1 = (double*) new double;
   
   saveLoadCells = true;

   while(saveLoadCells)
   {
      begin = clock();

      // Read the data from the load cells
      PhidgetVoltageRatioInput_getVoltageRatio(ch_LC0, voltageRatio_lco);
      PhidgetVoltageRatioInput_getVoltageRatio(ch_LC1, voltageRatio_lc1);  
   
      // save the data in a file
      ms = duration_cast< milliseconds >(system_clock::now().time_since_epoch());
      fileStreamLC << ms.count() << ", " << (*voltageRatio_lco + *voltageRatio_lc1)*voltToNewton  << std::endl;

      // Wait for the load cells to grab new data
      elapsed_secs = double(clock() - begin) / CLOCKS_PER_SEC;
      usleep(20000-elapsed_secs*1000);
   }

   // Close the file to save the data
   fileStreamLC.close();
}

void phidgetsClass::stopLoadCells()
{
   saveLoadCells = false;
}

void phidgetsClass::set_lcFileName(std::string name)
{
   lcFileName = name;
}

void phidgetsClass::set_lc0FileName(std::string name)
{
   lc0FileName = name;
}


void phidgetsClass::set_lc1FileName(std::string name)
{
   lc1FileName = name;
}



/* ----------------------------------- */
/* ---------- Error message ---------- */
/* ----------------------------------- */

void phidgetsClass::displayError()
{
   if (res != EPHIDGET_OK) 
   {
      if (res == EPHIDGET_TIMEOUT) 
      {
         printf("Channel did not attach: please check that the device is attached\n");
      } 
      else 
      {
         Phidget_getErrorDescription(res, &errs);
	 fprintf(stderr, "failed to open channel:%s\n", errs);
      }
   }
}

/* -------------------------------------- */
/* ---------- Export to python ---------- */
/* -------------------------------------- */
BOOST_PYTHON_MODULE(phidgetsClass_ext)
{
    using namespace boost::python;
    class_<phidgetsClass>("phidgetsClass", init<>())
        .def("runConveyors", &phidgetsClass::runConveyors)
        .def("runConveyor_0", &phidgetsClass::runConveyor_0)
        .def("runConveyor_1", &phidgetsClass::runConveyor_1)
        .def("stopConveyors", &phidgetsClass::stopConveyors)
        .def("stopConveyor_0", &phidgetsClass::stopConveyor_0)
        .def("stopConveyor_1", &phidgetsClass::stopConveyor_1)
        .def("initStepper", &phidgetsClass::initStepper)
        .def("moveStepper", &phidgetsClass::moveStepper)
        .def("stopStepper", &phidgetsClass::stopStepper)
        .def("runMotors", &phidgetsClass::runMotors)
        .def("stopMotors", &phidgetsClass::stopMotors)
        .def("runMotorsLoop", &phidgetsClass::runMotorsLoop)
        .def("stopMotorsLoop", &phidgetsClass::stopMotorsLoop)
        .def("loadCells", &phidgetsClass::loadCells)
        .def("stopLoadCells", &phidgetsClass::stopLoadCells)
        .def("set_lcFileName", &phidgetsClass::set_lcFileName)
        .def("set_lc0FileName", &phidgetsClass::set_lc0FileName)
        .def("set_lc1FileName", &phidgetsClass::set_lc1FileName)
    ;
}
